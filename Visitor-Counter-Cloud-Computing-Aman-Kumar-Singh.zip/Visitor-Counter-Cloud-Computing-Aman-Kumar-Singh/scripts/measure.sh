#!/usr/bin/env bash
set -euo pipefail

echo "=== Docker Images ==="
docker images | grep -E "visitor-counter|redis" || true

echo "=== Kubernetes Deployments & HPA ==="
kubectl get deployments,hpa,pods,svc || true
