#!/usr/bin/env bash
set -euo pipefail

URL="${1:-http://localhost:8080/info}"
echo "Polling $URL every 1s (Ctrl+C to stop)..."
while true; do
  BODY=$(curl -sS --max-time 2 "$URL" || echo '{"cluster":"unreachable"}')
  echo "$(date -Iseconds) -> $BODY"
  sleep 1
done
