from pathlib import Path
from PIL import Image, ImageDraw

out = Path(__file__).resolve().parent / "architecture.png"
img = Image.new("RGB", (1100, 460), "#f8fafc")
draw = ImageDraw.Draw(img)

draw.rectangle([20, 20, 1080, 440], outline="#cbd5e1", width=2, fill="#ffffff")
draw.text((40, 36), "Visitor Counter - Hybrid Cloud Failover Architecture (Aman Kumar Singh | 2410030293)", fill="#0f172a")

draw.rounded_rectangle([50, 160, 230, 260], radius=12, fill="#fef3c7", outline="#d97706", width=2)
draw.text((72, 198), "User / Browser / curl", fill="#78350f")

draw.rounded_rectangle([290, 145, 490, 275], radius=12, fill="#dcfce7", outline="#16a34a", width=2)
draw.text((312, 175), "Nginx Gateway (:8080)", fill="#14532d")
draw.text((312, 205), "Primary -> :8081", fill="#166534")
draw.text((312, 228), "Backup  -> :8082", fill="#166534")

draw.rounded_rectangle([560, 65, 1030, 195], radius=12, fill="#eff6ff", outline="#2563eb", width=2)
draw.text((580, 82), "PRIVATE CLUSTER (Kind :8081) - Primary", fill="#1e3a8a")
draw.text((580, 112), "Service web (NodePort 30080) -> Web Pods (2-6, HPA 50% CPU)", fill="#1d4ed8")
draw.text((580, 142), "Service redis (ClusterIP 6379) -> Redis Pod + Probes", fill="#1d4ed8")

draw.rounded_rectangle([560, 235, 1030, 365], radius=12, fill="#fef2f2", outline="#dc2626", width=2)
draw.text((580, 252), "PUBLIC CLUSTER (Kind :8082) - Failover Backup", fill="#7f1d1d")
draw.text((580, 282), "Service web (NodePort 30080) -> Web Pods (2-6, HPA 50% CPU)", fill="#b91c1c")
draw.text((580, 312), "Service redis (ClusterIP 6379) -> Redis Pod + Probes", fill="#b91c1c")

draw.line([230, 210, 290, 210], fill="#334155", width=3)
draw.line([490, 185, 560, 130], fill="#16a34a", width=3)
draw.line([490, 235, 560, 300], fill="#dc2626", width=3)

img.save(out)
print("Saved", out)
