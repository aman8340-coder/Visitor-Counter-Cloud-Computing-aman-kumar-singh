import os
import socket
import time
from flask import Flask, jsonify, render_template
import redis

app = Flask(__name__)

REDIS_HOST = os.getenv("REDIS_HOST", "redis")
REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
CLUSTER_NAME = os.getenv("CLUSTER_NAME", "local")

client = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    socket_connect_timeout=2,
    socket_timeout=2,
    decode_responses=True,
)


@app.route("/")
def index():
    pod_name = socket.gethostname()
    try:
        count = client.incr("visits")
    except redis.exceptions.RedisError:
        return "<h1>Redis unavailable</h1>", 503
    return render_template(
        "index.html",
        count=count,
        pod=pod_name,
        cluster=CLUSTER_NAME,
    )


@app.route("/info")
def info():
    return jsonify({
        "cluster": CLUSTER_NAME,
        "pod": socket.gethostname(),
    })


@app.route("/health")
def health():
    return "ok", 200


@app.route("/ready")
def ready():
    try:
        if client.ping():
            return "ready", 200
    except redis.exceptions.RedisError:
        pass
    return "redis not reachable", 503


@app.route("/work")
def work():
    total = 0
    for i in range(300000):
        total += i * i
    return jsonify({
        "status": "completed",
        "iterations": 300000,
        "pod": socket.gethostname(),
        "cluster": CLUSTER_NAME,
        "checksum": total % 1000007,
    })


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
