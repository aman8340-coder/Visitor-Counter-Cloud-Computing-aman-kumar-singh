HOURS_PER_MONTH = 730
VCPU_HOUR_RATE = 0.04048
GIB_HOUR_RATE = 0.004445


def scenario_cost(web_replicas: int, web_cpu_m: int, web_mem_mib: int, redis_replicas: int = 1, redis_cpu_m: int = 50, redis_mem_mib: int = 32) -> float:
    total_vcpu = (web_replicas * web_cpu_m + redis_replicas * redis_cpu_m) / 1000.0
    total_gib = (web_replicas * web_mem_mib + redis_replicas * redis_mem_mib) / 1024.0
    return round((total_vcpu * VCPU_HOUR_RATE + total_gib * GIB_HOUR_RATE) * HOURS_PER_MONTH, 2)


if __name__ == "__main__":
    before = scenario_cost(6, 500, 512)
    after = scenario_cost(2, 100, 64)
    saving = round(before - after, 2)
    pct = round((saving / before) * 100, 1)
    print(f"Before: USD {before:.2f}/month")
    print(f"After (avg 2 web pods): USD {after:.2f}/month")
    print(f"Saving: USD {saving:.2f}/month ({pct}%)")
